﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Phonebook.Models
{
    public class PhoneBookEntryModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string PhoneBookName { get; set; }
        public string PhoneBookId { get; set; }
    }
}
