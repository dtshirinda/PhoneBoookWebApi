﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Phonebook.Models
{
    public class ResponseModel
    {
        public HttpStatusCode HttpStatusCode { get; set; }
        public string ResponseMessage { get; set; }

        public ResponseModel(HttpStatusCode httpStatusCode, string responseMessage)
        {
            this.HttpStatusCode = httpStatusCode;
            this.ResponseMessage = responseMessage;
        }
    }
}
