﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Phonebook.BusinessLogic.Interface;
using Phonebook.BusinessLogic.Logic;
using Phonebook.Models.Entry;
using Phonebook.Models.PhoneBook;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhonebookApi.Controllers
{
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]")]
    [ApiController]
    public class PhoneBookController : ControllerBase
    {
        private readonly IPhonebookBusinessLogic _phonebookBusinessLogic;
        private readonly IEntryBusinessLogic _entryBusinessLogic;
        private readonly IConfiguration _config;

        public PhoneBookController(IPhonebookBusinessLogic phonebookBusinessLogic, IEntryBusinessLogic entryBusinessLogic, IConfiguration config)
        {
            this._phonebookBusinessLogic = phonebookBusinessLogic;
            this._entryBusinessLogic = entryBusinessLogic;
            this._config = config;
        }

        [HttpPost("PhoneBook/AddUpdateEntry")]
        public IActionResult CreateEntry([FromBody]EntryDomainModel entry)
        {
            if (ModelState.IsValid)
            {
                var dbConnection = _config.GetValue<string>("DbConnection");
                var result = this._entryBusinessLogic.AddEntry(entry, dbConnection);
                return this.Ok(result);
            }
            else
            {
               return this.BadRequest(ModelState);
            }
        }

        [HttpGet("PhoneBook/GetEntries")]
        public IActionResult GetPhoneDetails()
        {
            var dbConnection = _config.GetValue<string>("DbConnection");
            var result = _entryBusinessLogic.GetEntries(dbConnection);
            return this.Ok(result);
        }
    }
}
