﻿using Phonebook.Models;
using Phonebook.Models.PhoneBook;
using System;
using System.Collections.Generic;
using System.Text;

namespace Phonebook.BusinessLogic.Interface
{
    public interface IPhonebookBusinessLogic
    {
        ResponseModel AddPhoneBook(PhoneBookDomainModel phoneBook);
        ResponseModel EditPhoneBook(PhoneBookDomainModel phonebook);
        PhoneBookDomainModel GetPhoneBook(string guid);
        List<PhoneBookDomainModel> GetPhoneBooks();
    }
}
