﻿
using System;
using System.Collections.Generic;
using System.Text;
using Phonebook.Models;
using Phonebook.Models.Entry;

namespace Phonebook.BusinessLogic.Interface
{
    public interface IEntryBusinessLogic
    {
        ResponseModel AddEntry(EntryDomainModel entry, string dbConn);
        ////void EditEntry(Entry entry);
        ////Entry GetEntry(string guid);
        List<PhoneBookEntryModel> GetEntries(string dbConn);
    }
}
