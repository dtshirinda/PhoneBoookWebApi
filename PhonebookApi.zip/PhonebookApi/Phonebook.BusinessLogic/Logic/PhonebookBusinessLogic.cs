﻿using Phonebook.BusinessLogic.Interface;
using Phonebook.Infrastructure.Interface;
using Phonebook.Infrastructure.Repository;
using Phonebook.Models;
using Phonebook.Models.PhoneBook;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Phonebook.BusinessLogic.Logic
{
    public class PhonebookBusinessLogic : IPhonebookBusinessLogic
    {
        private readonly IPhonebookRepository _phonebookRepository;

        public PhonebookBusinessLogic(IPhonebookRepository phonebookRepository)
        {
            this._phonebookRepository = phonebookRepository;
        }

        public ResponseModel AddPhoneBook(PhoneBookDomainModel phoneBook)
        {
            this._phonebookRepository.AddPhoneBook(phoneBook);

            return new ResponseModel(HttpStatusCode.OK, "Successfully Added");
        }

        #region not implemented

        public ResponseModel EditPhoneBook(PhoneBookDomainModel phonebook)
        {
            throw new NotImplementedException();
        }

        public PhoneBookDomainModel GetPhoneBook(string guid)
        {
            throw new NotImplementedException();
        }

        public List<PhoneBookDomainModel> GetPhoneBooks()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
