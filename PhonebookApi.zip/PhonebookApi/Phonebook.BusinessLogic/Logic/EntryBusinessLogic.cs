﻿using Phonebook.BusinessLogic.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using Phonebook.Models.Entry;
using Phonebook.Infrastructure.Repository;
using Phonebook.Models;
using System.Net;
using Phonebook.Infrastructure.Interface;

namespace Phonebook.BusinessLogic.Logic
{
    public class EntryBusinessLogic : IEntryBusinessLogic
    {
        private readonly IEntryRepository _entryRepository;

        public EntryBusinessLogic(IEntryRepository entryRepository)
        {
            this._entryRepository = entryRepository;
        }

        public ResponseModel AddEntry(EntryDomainModel entry, string dbConn)
        {
            var code = entry.PhoneNumber.Substring(0, 1);  /// Validate against country calling code

            if (entry.PhoneNumber.Length == 10 && Int64.TryParse(entry.PhoneNumber, out long number))
            {
                this._entryRepository.AddEntry(entry, dbConn);
            }
            else
            {
                return new ResponseModel(HttpStatusCode.BadRequest, "Invalid Phone numbers");
            }

            return new ResponseModel(HttpStatusCode.OK, "Successfully Added");
        }

        public List<PhoneBookEntryModel> GetEntries(string dbConn)
        {
            var result = this._entryRepository.GetEntries(dbConn);
            return result;
        }
    }
}
