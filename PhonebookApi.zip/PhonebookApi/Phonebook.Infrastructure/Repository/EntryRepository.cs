﻿using Phonebook.Infrastructure.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Phonebook.Models.Entry;
using Phonebook.Models;

namespace Phonebook.Infrastructure.Repository
{
    public class EntryRepository : IEntryRepository
    {
        public void AddEntry(EntryDomainModel entry, string dbConn)
        {
            SqlConnection connection = new SqlConnection(dbConn);
            connection.Open();
            SqlCommand cmd = new SqlCommand("InsertUpdateEntryPhoneBook", connection);
            cmd.Parameters.AddWithValue("@Id", entry.Id);
            cmd.Parameters.AddWithValue("@Name", entry.Name);
            cmd.Parameters.AddWithValue("@PhoneNumber", entry.PhoneNumber);
            cmd.Parameters.AddWithValue("@PhoneBookName", entry.PhoneBookName);
            cmd.Parameters.AddWithValue("@PhoneBookId", entry.PhoneBookId);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public List<PhoneBookEntryModel> GetEntries(string dbConn)
        {
            var entries = new List<PhoneBookEntryModel>();
            SqlConnection connection = new SqlConnection(dbConn);
            connection.Open();
            SqlCommand cmd = new SqlCommand("GetAllEntries", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    entries.Add(new PhoneBookEntryModel()
                    {
                        Name =  Convert.ToString(reader["Name"]),
                        PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                        PhoneBookName = Convert.ToString(reader["PhoneBookName"]),
                        PhoneBookId = Convert.ToString(reader["PhoneBookId"]),
                        Id = Convert.ToString(reader["Id"]),
                    });
                }
            }
            return entries;
        }
    }
}
