﻿using Phonebook.Infrastructure.Interface;
using Phonebook.Models.PhoneBook;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Microsoft.Extensions.Configuration;
using Phonebook.Models;

namespace Phonebook.Infrastructure.Repository
{
    public class PhonebookRepository : IPhonebookRepository
    {
        private static string dbConnect = "Server=DOUGLAS-SHIRIND;Database=PhoneBookDB;Trusted_Connection=True;";

        public ResponseModel AddPhoneBook(PhoneBookDomainModel phoneBook)
        {
            SqlConnection connection = new SqlConnection(dbConnect);
            connection.Open();
            SqlCommand cmd = new SqlCommand("InsertUpdatePhoneBook", connection);
            cmd.Parameters.AddWithValue("@Id", phoneBook.Id);
            cmd.Parameters.AddWithValue("@Name", phoneBook.Name);
            cmd.Parameters.AddWithValue("@EntryId", phoneBook.Id);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            return null;
        }
    }
}
