﻿using System;
using System.Collections.Generic;
using System.Text;
using Phonebook.Models;
using Phonebook.Models.Entry;

namespace Phonebook.Infrastructure.Interface
{
    public interface IEntryRepository
    {
         void AddEntry(EntryDomainModel entry, string dbConn);
        List<PhoneBookEntryModel> GetEntries(string dbConn);
    }
}
