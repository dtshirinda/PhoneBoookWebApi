﻿
using Phonebook.Models;
using Phonebook.Models.PhoneBook;
using System;
using System.Collections.Generic;
using System.Text;

namespace Phonebook.Infrastructure.Interface
{
    public interface IPhonebookRepository
    {
        ResponseModel AddPhoneBook(PhoneBookDomainModel phoneBook);
    }
}
