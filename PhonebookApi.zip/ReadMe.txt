
HOW TO ROW THE API 
1. Change the database connection from the AppSettings to your connection string.
2. Create database called PhoneBookDB 
2. Run create table for the following table (Script Attached) 
	Entry
	PhoneBook

3 Run the following attached scripts
	InsertUpdatePhoneBook
	InsertUpdateEntryPhoneBook
	GetAllEntries

HOW TO RUN THE FRONT END (Angular Application)
1. Run NPM START command 