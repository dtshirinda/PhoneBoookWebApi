import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HttpEventType, HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { PhoneBook } from './phoneBook';
import { RequestResponse } from './response';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.styl']
})

export class AppComponent implements OnInit  {

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) { }
  title = 'Phone Book App';
  baseUrl = 'https://localhost:44307/api/PhoneBook/PhoneBook';
  public progress: number;
  public message: string;
  public data: PhoneBook[] = [];
  public isLoading = true;
  public addingMode = true;
  public hideCrud = false;
  public model: PhoneBook;
  responseMessage = '';
// tslint:disable-next-line: no-output-on-prefix
  @Output() public onUploadFinished = new EventEmitter();

   httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Access-Control-Allow-Origin': '*'
      })
    };

  ngOnInit() {
    this.model = new PhoneBook();
    this.getEntries();
  }


  postEntries() {
    const value =  JSON.stringify(this.model) ;
    this.http.post<any>(`${this.baseUrl}/AddUpdateEntry`,  value, this.httpOptions)
    .subscribe(response => {
          const result = response as RequestResponse;
          if  (result) {
            if (result.httpStatusCode === 200) {
              this.refresh();
           }

            this.responseMessage = result.responseMessage;
        }
      }
    );
  }

  getEntries() {
    this.http.get(`${this.baseUrl}/GetEntries`)
      .subscribe(event => {
         this.data =  event as PhoneBook[];
         this.isLoading = false;
      });
    }

    refresh() {
      this.model = new PhoneBook();
      this.getEntries();
    }

  cancel() {
   this.refresh();
  }

    Edit(id: string) {
        if (this.data) {
          const found = this.data.find(element => element.id === id);
          if (found) {
            this.model = found;
          }
        }
    }
}
