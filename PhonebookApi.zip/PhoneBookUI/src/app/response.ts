export class RequestResponse {
    public httpStatusCode: number;
    public responseMessage: string;
}