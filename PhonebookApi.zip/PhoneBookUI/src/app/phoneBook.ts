export class PhoneBook {
      public id: string;
      public name: string;
      public phoneNumber: string;
      public phoneBookName: string;
      public phoneBookId: string;
  }